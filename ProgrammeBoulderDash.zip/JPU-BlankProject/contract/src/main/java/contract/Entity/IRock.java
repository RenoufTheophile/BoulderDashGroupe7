package contract.Entity;

public interface IRock {

    boolean getFalling();

    void setFalling(boolean falling);

}
