package model.entity;

/**
 * @author Marc-Adrien Pointel
 * I need some more valuable rock
 */

public class Diamand extends Rock {


    /**
     * instantiation of diamand position
     * @param x
     * @param y
     */
    public Diamand(int x, int y) {
        super(x, y);
    }

}


