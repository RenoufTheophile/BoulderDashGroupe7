package controller;

import model.entity.Hero;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ControllerTest {
    private Hero test;

    @Before
    public void setUp()  {
        test = new Hero(1,1);
    }

    @After
    public void tearDown()  {
    }

    @Test
    public void findRock() throws Exception{
    }

    @Test
    public void findDiamand() throws Exception{
    }

    @Test
    public void findMonster() throws Exception{
    }

    @Test
    public void fall() throws Exception{
    }

    @Test
    public void fall1() throws Exception{
    }

    @Test
    public void moving() throws Exception{
    }

    @Test
    public void michaelBay() throws Exception{
    }

    @Test
    public void dpH() throws Exception{

    }

    @Test
    public void dpD() throws Exception{

    }

    @Test
    public void dpB() throws Exception{

    }

    @Test
    public void dpG() throws Exception{
     
    }
}