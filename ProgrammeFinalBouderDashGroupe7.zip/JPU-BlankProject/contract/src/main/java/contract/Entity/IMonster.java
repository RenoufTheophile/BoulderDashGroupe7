package contract.Entity;

public interface IMonster {


    char getSensDp();

    void setSensDp(char sensDp);

    }
