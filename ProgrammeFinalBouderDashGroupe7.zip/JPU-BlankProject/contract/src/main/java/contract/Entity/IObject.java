package contract.Entity;

public interface IObject {

     int getX() ;

     int getY() ;

     boolean getExisting() ;


     void setX(int x) ;

     void setY(int y) ;

     void setExisting(boolean existing) ;
}
