package contract;

public interface IMapLoad {



}
