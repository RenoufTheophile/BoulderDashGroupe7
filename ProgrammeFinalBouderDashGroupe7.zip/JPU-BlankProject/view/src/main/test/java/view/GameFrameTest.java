package view;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class GameFrameTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void display() throws Exception {
    }

    @Test
    public void keyTyped() throws Exception{
    }

    @Test
    public void keyPressed() throws Exception{
    }

    @Test
    public void keyReleased() throws Exception {
    }
}